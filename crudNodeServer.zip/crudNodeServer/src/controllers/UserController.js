const userController ={};

userController.signIn = (req, res) => {
    let userID=req.body.userID;
    user.findOne({ userID: userID }).then(function (data) {
      // checking for Admin User
      if (data!= null && data.role=="Admin") {
        if(!req.body.password)
          res.send({user:"Admin"});
        else{
            if(data.password==req.body.password){
              res.send("authenticated");
            }else{
              res.send("Authentication Failed");
            }
        }
      }else{
        // saving Guest User
        var userData={
          _id:new mongoose.Types.ObjectId(),
          userID:req.body.userID,
          phoneNumber:body.phoneNumber
        }
        let newUser = new user(userData);
        newUser.save((err, data) => {
          if (err) {
            res.send(err);
          }
          res.send({user:"Guest"});
        });
      }
    })
  }

export default userController;