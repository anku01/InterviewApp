import mongoose from 'mongoose';
import questionSchema from '../models/QuestionModel';

const questions = mongoose.model('question', questionSchema);

const addaQuestion = (req, res) => {
    let newQuestion = new questions(req.body);

    newQuestion.save((err, question) => {
        if(err){
            res.send(err);
        }
        res.json(question);
    });
};

const getQuestions = (req, res) => {   
    questions.find({}, (err, question) => {
        if(err){
            res.send(err);
        }
        res.json(question);
    });
};

const getQuestionById = (req, res) => {
    questions.findById(req.params.questionId, (err, question) => {
        if(err){
            res.send(err);
        }
        res.json(question);      
    });
};

const updateQuestion = (req, res) => {
    questions.findByIdAndUpdate({_id: req.params.questionId}, req.body, {new: true}, (err, question) => {
        if(err){
            res.send(err);
        }
        res.json(book);
    })
};

const deleteQuestion = (req, res) => {
    questions.remove({_id: req.params.questionId}, (err, question) => {
        if(err){
            res.send(err);
        }
        res.json({message: 'Successfully deleted a Question.'});
    })
}
export {addaQuestion, getQuestions, getQuestionById, updateQuestion, deleteQuestion}