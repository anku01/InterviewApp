import express from "express";
import {
    addaQuestion, 
    getQuestions, 
    getQuestionById, 
    updateQuestion, 
    deleteQuestion,
} from '../controllers/QuestionController';
const app = express();

const routes = () => {
    app.route('/question')
    .get((req, _res, next)=> {
        console.log(`Request method ${req.method}`);
        next();
    }, getQuestions)

    .post(addaQuestion);

    app.route('/question/:questionId')
    .get(getQuestionById)
    .put(updateQuestion)
    .delete(deleteQuestion);
} 

export default routes;