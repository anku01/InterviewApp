import express from "express";
import userController from "../controllers/UserController";

const router = express.Router();

router.post('adminLogin',(req, res, next)=>{
  console.log("success");
  userController.signIn(req,res);
});
router.post('candidateLogin',(req, res, next)=>{
    userController.signIn(req,res);
  });
export default router;