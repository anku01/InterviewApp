import mongoose from 'mongoose';

const question = mongoose.Schema;

const questionSchema = new question({
    answertype: {
        type: String,
        required: 'select the answer type'
       },
    question: {
        type: String,
        required: 'Enter the book title.'
    },
    optiona: {
        type: String,
        required: 'Enter the option a'
    },
    optionb: {
        type: Number,
        required: 'Enter the option b'
    },
    optionc: {
        type: String,
        required: 'Enter the option c'
    },
    optiond: {
        type: String,
        required: 'Enter the option d'
    },
    optionCorrect: {
        type: String,
        required: 'Enter the correct answer'
    },
    severity: {
        type: Number,
        required: 'Enter complexity'
    },
    Technology: {
        type: String,
        required: 'Enter Type of Technology'
    },
    
    created_date: {
        type: Date,
        default: Date.now
    }
});

export default questionSchema;