import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const UserSchema = Schema({
  _id: Schema.Types.ObjectId,
  role:{
    type:String,
    default:"Guest"
  },
  emailID:{
    type:String,
    required:"User ID required",
  },
  password:{
    type:String,
    default:null,
  },
  phonenumber:{
    type:String,
    default:null,
  },

});

let UserModel = mongoose.model('users', UserSchema);
export default UserModel;